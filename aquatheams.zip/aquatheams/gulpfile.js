<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
</head>
<body>

<table style="width:100%">
  <tr>
    <th>Eno</th>
    <th>Ename</th> 
    <th>addr</th>
  </tr>
  <tr>
    <td>101</td>
    <td>raj</td>
    <td>bangalore</td>
  </tr>
  <tr>
    <td>102</td>
    <td>Jack</td>
    <td>tamilnadu</td>
  </tr>
  <tr>
    <td>103</td>
    <td>Doe</td>
    <td>chennai</td>
  </tr>
</table>

</body>
</html>
