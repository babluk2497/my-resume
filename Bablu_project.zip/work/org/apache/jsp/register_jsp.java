package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.ResultSet;
import com.Dao.Utility;
import com.Dao.LoginDao;

public final class register_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write(".checkboxFour {\r\n");
      out.write("\twidth: 40px;\r\n");
      out.write("\theight: 40px;\r\n");
      out.write("\tbackground: #ddd;\r\n");
      out.write("\tmargin: 20px 90px;\r\n");
      out.write("\r\n");
      out.write("\tborder-radius: 100%;\r\n");
      out.write("\tposition: relative;\r\n");
      out.write("\tbox-shadow: 0px 1px 3px rgba(0,0,0,0.5);\r\n");
      out.write("}\r\n");
      out.write("</style>\r\n");
      out.write("<script>\r\n");
      out.write("        function validateEmail(emailField)\r\n");
      out.write("        {\r\n");
      out.write("        var reg = /^([A-Za-z0-9_\\-\\.])+\\@([A-Za-z0-9_\\-\\.])+\\.([A-Za-z]{2,4})$/;\r\n");
      out.write("\r\n");
      out.write("        if (reg.test(emailField.value) == false) \r\n");
      out.write("        {\r\n");
      out.write("            alert('Invalid Email Address');\r\n");
      out.write("            emailField.value = null;\r\n");
      out.write("            return false;\r\n");
      out.write("        }\r\n");
      out.write("\r\n");
      out.write("        return true;\r\n");
      out.write("\r\n");
      out.write("}\r\n");
      out.write("        </script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("        \r\n");
      out.write("\t\t<link rel=\"shortcut icon\" href=\"../favicon.ico\" type=\"image/x-icon\"/>\r\n");
      out.write("        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style1.css\" />\r\n");
      out.write("\t\t<script src=\"js/cufon-yui.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t\t\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/Javascript/register.js\"></script>\r\n");
      out.write("\t\t<script src=\"js/ChunkFive_400.font.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t\tCufon.replace('h1',{ textShadow: '1px 1px #fff'});\r\n");
      out.write("\t\t\tCufon.replace('h2',{ textShadow: '1px 1px #fff'});\r\n");
      out.write("\t\t\tCufon.replace('h3',{ textShadow: '1px 1px #000'});\r\n");
      out.write("\t\t\tCufon.replace('.back');\r\n");
      out.write("\t\t</script>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<link href=\"css/js-image-slider.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("   \t\t<script src=\"");
      out.print(request.getContextPath());
      out.write("/js/js-image-slider.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t \t <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\r\n");
      out.write("         <link rel=\"stylesheet\" type=\"text/css\" href=\"css/message.css\" />\r\n");
      out.write("         <script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath() );
      out.write("/Resources/JS/style.js\"></script>\r\n");
      out.write("         ");

		  ResultSet rs= LoginDao.landmark();
         System.out.println("}}}}}}}}}}}}}}}}}}}}"+rs);
		
      out.write("\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("    var mytextbox = document.getElementById('mytext');\r\n");
      out.write("    var mydropdown = document.getElementById('dropdown');\r\n");
      out.write("\r\n");
      out.write("    mydropdown.onchange = function(){\r\n");
      out.write("          mytextbox.value = mytextbox.value  + this.value; //to appened\r\n");
      out.write("         //mytextbox.innerHTML = this.value;\r\n");
      out.write("    }\r\n");
      out.write("</script>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");
      out.write("    </head>\r\n");
      out.write("    <body>\r\n");
      out.write("    \t<img src=\"");
      out.print(request.getContextPath() );
      out.write("/images/titleimage.png\"  width=\"100%\"  \"></img>\r\n");
      out.write("   \t\t <div id=\"slider\" style=\"margin-top: 15px;\" >\r\n");
      out.write("        \t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/1a.jpg\" />\r\n");
      out.write("        \t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/2a.jpg\"  />\r\n");
      out.write("        \t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/5a.jpg\"  />\r\n");
      out.write("        \t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/7a.jpg\"  />\r\n");
      out.write("       \t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/8a.jpg\"  />\r\n");
      out.write("       \t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/9a.jpg\"  />\r\n");
      out.write("       \t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Web_work/10a.jpg\"  /> \t \r\n");
      out.write("       \t\t\r\n");
      out.write("   \t\t </div>\r\n");
      out.write("   \t\t <div id=\"textscrolling\" style=\"margin-top: 50px;\" >\r\n");
      out.write("\t\t\t<marquee scrollamount=\"2\" scrolldelay=\"10\"  direction=\"up\" width=\"350\" height=\"500\" onmouseover=\"this.setAttribute('scrollamount',0,0)\" onmouseout=\"this.setAttribute('scrollamount',2,0)\"  style=\"font-family: cursive; font-size: 12pt\">\r\n");
      out.write("\t\t\t\t\t\tOne characteristic of online social networking services\r\n");
      out.write("\t\t\t\t\tis their emphasis on the users and their connections,\r\n");
      out.write("\t\t\t\t\tin addition to the content as seen in traditional Internet services. \r\n");
      out.write("\t\t\t\t\t<br><br>\r\n");
      out.write("\t\t\t\t\tOnline social networking data, once published, are of\r\n");
      out.write("\t\t\t\t\tgreat interest to a large audience: Sociologists can verify\r\n");
      out.write("\t\t\t\t\thypotheses on social structures and human behavior\r\n");
      out.write("\t\t\t\t\tpatterns\r\n");
      out.write("\t\t\t\t\t<br><br>\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\r\n");
      out.write("\t\t\t</marquee>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<div class=\"wrapper\">\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t<div class=\"content\">\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t<div id=\"form_wrapper\" class=\"form_wrapper\" style=\"margin-top: 12px;\">\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<!-------------------------------Register Form -------------------------------------->\r\n");
      out.write("\t\t\t\t\t<form class=\"register active\" action=\"");
      out.print(request.getContextPath());
      out.write("/Register\" enctype=\"multipart/form-data\" method=\"post\" >\r\n");
      out.write("\t\t\t\t\t\t<h3 style=\"height: 25px;\">Register</h3>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label style=\"padding-top: 10px;\">Name:</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"text\" name=\"name\" required=\"yes\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label>User ID(Email ID):</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t <input type=\"text\" name=\"userid\" pattern=\"\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*\"  required /> \r\n");
      out.write("\t\t\t\t\t\t\t<!-- \t<input type=\"text\" name=\"userid\" onblur=\"validateEmail(this);\" required /> -->\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label>Password:</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"password\" name=\"password\"  required=\"yes\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t<table>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t<label>Birthday:</label></tr>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td><select name=\"day\" id=\"day\"  class=\"day\" required=\"yes\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<option value=\"\">Day</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t");

										for(int i=1; i<=31;i++)
										{
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<option value=\"");
      out.print(i );
      out.write('"');
      out.write('>');
      out.print(i );
      out.write("</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t</select></td>\r\n");
      out.write("\t\t\t\t\t\t\t<td >\t\r\n");
      out.write("\t\t\t\t\t\t<select id=\"BirthMonth\" name=\"BirthMonth\" class=\"month\" required=\"yes\" >\r\n");
      out.write("\t\t\t\t\t\t\t<option value=\"\">Month</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"01\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  January</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"02\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  February</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"03\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  March</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"04\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  April</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"05\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  May</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"06\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  June</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"07\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  July</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"08\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  August</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"09\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  September</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"10\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  October</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"11\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  November</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t  <option value=\"12\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t  December</option>\r\n");
      out.write("\t\t\t\t\t\t\t</select></td>\r\n");
      out.write("\t\t\t\t\t\t<td><select name=\"year\" id=\"year\"  class=\"year\" required=\"yes\"> \r\n");
      out.write("\t\t\t\t\t\t\t\t<option value=\"\">year</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t");

										for(int i=1950; i<=2014;i++)
										{
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<option value=\"");
      out.print(i );
      out.write('"');
      out.write('>');
      out.print(i );
      out.write("</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t</select></td>\r\n");
      out.write("\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label>Gender:</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<select id=\"gender\" name=\"gender\" class=\"gender\" required=\"yes\">\r\n");
      out.write("\t  \t\t\t\t\t\t\t\t\t<option value=\"\">I am...</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<option value=\"FEMALE\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\tFemale</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<option value=\"MALE\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\tMale</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<option value=\"OTHER\" >\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\tOther</option>\r\n");
      out.write("\t\t\t\t\t\t\t\t</select>\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label style=\"padding-top: 10px;\">Hobby:</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"text\" name=\"hobby\" required=\"yes\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label style=\"padding-top: 10px;\">Place:</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"text\" name=\"place\" required=\"yes\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div style=\"height: 65px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label>Mobile No.</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"text\" name=\"mobile\"  required=\"yes\"  pattern=\"[7-9]{1}[0-9]{9}\"  maxlength=\"10\" height=\"10\" />\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t<div style=\"height: 55px\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<label>Upload Profile Pic</label>\r\n");
      out.write("\t\t\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"file\" name=\"pfl_pic\"  required=\"yes\"  />\r\n");
      out.write("\t\t\t\t\t\t\t\t<span class=\"error\">This is an error</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t<div class=\"bottom\">\r\n");
      out.write("\t\t\t\t\t\t\t<!-- <div class=\"remember\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<input type=\"checkbox\" />\r\n");
      out.write("\t\t\t\t\t\t\t\t<span>Send me updates</span>\r\n");
      out.write("\t\t\t\t\t\t\t</div> -->\r\n");
      out.write("\t\t\t\t\t\t\t<input type=\"submit\" value=\"Register\" onclick=\"return register()\"/>\r\n");
      out.write("\t\t\t\t\t\t\t<a href=\"index.jsp\" rel=\"login\" >You have an account already? Log in here</a>\r\n");
      out.write("\t\t\t\t\t\t\t<div class=\"clear\"></div>\r\n");
      out.write("\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t<div class=\"clear\"></div>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t");

		int no=Utility.parse(request.getParameter("no"));
			
		if(no==1)
{
	
      out.write("\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t<div class=\"error\" id=\"message\" style=\"margin-left:-400px; margin-top:-200px; height: 100px;width: 300px;\" >\t\r\n");
      out.write("\t\t\t<p>User Name Already Exists!! Try With Another One... </p>\r\n");
      out.write("\t\t</div>\r\n");

}

      out.write("\r\n");
      out.write("\r\n");
      out.write("    </body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
