package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.Dao.GroupDAO;
import java.util.*;

public final class post_005frequest_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

 String f_name=""; 
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("\t<link href=\"");
      out.print(request.getContextPath() );
      out.write("/Res/CSS/style.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write('\r');
      out.write('\n');

	String user = request.getParameter("user");
	Vector <String> v=GroupDAO.get_post_Req(user);
	Vector <String> v2=GroupDAO.get_post_Req_id(user);
	System.out.println("SIve of vector"+v.size());
	for(int i=0;i<v.size();i++)
	{
      out.write("\r\n");
      out.write("\t\t<div class=\"request\">\r\n");
      out.write("\t\t<form action=\"");
      out.print(request.getContextPath() );
      out.write("/Update_post\">\r\n");
      out.write("\t\t<p>");
      out.print(v.get(i) );
      out.write("</p>\r\n");
      out.write("\t\t<img height=\"50\" width=\"50\" src=\"");
      out.print(request.getContextPath() );
      out.write("/Res/Images/user.png\" style=\"padding-left:22px\" title=\"");
      out.print(v.get(i) );
      out.write("\"></img></a>\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"from\" value=\"");
      out.print(v.get(i) );
      out.write("\">\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"to\" value=\"");
      out.print(user );
      out.write("\">\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"p_id\" value=\"");
      out.print(v2.get(i) );
      out.write("\">\r\n");
      out.write("\t\t");
System.out.println("hhhhh"+v2.get(i));
		
		
		System.out.println("my pic nameis"+GroupDAO.get_post_Image(Integer.parseInt(v2.get(i)))); 
      out.write("\r\n");
      out.write("\t <img src=\"");
      out.print(request.getContextPath());
      out.write("/user_input_image/");
      out.print(GroupDAO.get_post_Image(Integer.parseInt(v2.get(i))));
      out.write("\" width=\"80px;\" height=\"80px;\"></img>\r\n");
      out.write("\t\r\n");
      out.write("\t\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<input id=\"button\" type=\"submit\" value=\"Accept\" name=\"task\"><input id=\"button\" name=\"task\" type=\"submit\" value=\"Reject\"> \r\n");
      out.write("\t\t</form>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t");
}

      out.write("\r\n");
      out.write("\t\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
