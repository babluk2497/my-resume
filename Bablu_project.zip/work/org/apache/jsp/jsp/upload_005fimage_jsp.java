package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.ResultSet;
import com.Dao.LoginDao;

public final class upload_005fimage_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<link href=\"");
      out.print(request.getContextPath() );
      out.write("/Resources/CSS/button.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<title>Insert title here</title>\r\n");
      out.write("<script language=\"javascript\">\r\n");
      out.write("\tfunction check()\r\n");
      out.write("\t{\r\n");
      out.write("\t\tif(document.f1.file.value.length==0)\r\n");
      out.write("\t\t{\r\n");
      out.write("\t\t\talert(\"Please Select a File\");\r\n");
      out.write("\t\t\treturn false\r\n");
      out.write("\t\t}\r\n");
      out.write("\t\telse\r\n");
      out.write("\t\t{\r\n");
      out.write("\t\t\treturn true;\r\n");
      out.write("\t\t}\r\n");
      out.write("\t}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body >\r\n");
      out.write("\t\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t <h3>Upload<span style=\"color:#710069;font-family: georgia,sans-serif;font-weight: bold;\"> Post</span> </h3>\r\n");
      out.write("\t\t");

			String x_name=(String)session.getAttribute("x_name"); 
			String x_profile=(String)session.getAttribute("x_profile");		
			String i_code=(String)request.getAttribute("i_code");
			String x_filename=(String)request.getAttribute("filename");
			String coowner=(String)request.getParameter("coowner");
			System.out.println("i_code jsp :"+i_code);
			System.out.println("x_filename jsp :"+x_filename);
			System.out.println("coowner :"+coowner);
			

			
			
		
      out.write("\r\n");
      out.write("\t\t  \r\n");
      out.write("\t\t\t<div style=\"height: 100%\" >\r\n");
      out.write("\t\t\t\t<table  align=\"center\" bordercolor=\"\" width=\"100px;\" height=\"200px;\" >\r\n");
      out.write("\t\t\t\t <form name=\"f1\" action=\"");
      out.print(request.getContextPath());
      out.write("/ReadFile\" method=\"post\" enctype=\"multipart/form-data\">\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<!-- <td style=\"padding-right: 100px;\"> -->\r\n");
      out.write("\t\t\t\t\t\t<td style=\"color: #710069;\" ><b>File Name</b></td>\r\n");
      out.write("\t\t\t\t\t\t<td>:</td>\r\n");
      out.write("\t\t\t\t\t\t<td><input type=\"file\"  name=\"file\" required=\"required\"></input></td>\r\n");
      out.write("\t\t\t\t\t\t<td><input type=\"submit\"  value=\"Upload Image\" class=\"gradientbuttons\" onclick=\"return check();\"></input></td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t  \t\t</form>\r\n");
      out.write("\t\t\t\t  <form name=\"f1\" action=\"");
      out.print(request.getContextPath());
      out.write("/CommentSubmit1\" method=\"post\" >\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td style=\"color: #710069; width: 150px\" ><b>Image</b></td>\r\n");
      out.write("\t\t\t\t\t\t\t<td>:</td>\r\n");
      out.write("\t\t\t\t\t\t\t<td><img src=\"");
      out.print(request.getContextPath());
      out.write("/user_input_image/");
      out.print(x_filename );
      out.write("\" width=\"100px;\" height=\"100px;\"></img></td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td style=\"color: #710069; width: 150px\" ><b>Comment</b></td>\r\n");
      out.write("\t\t\t\t\t\t\t<td>:</td>\r\n");
      out.write("\t\t\t\t\t\t\t<td>\r\n");
      out.write("\t\t\t\t\t\t\t\t<input id=\"s1\" type=\"text\" name=\"comment\"   placeholder=\"Write a comment...\" style=\"font-size: 15px; color: black;\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t<td><input type=\"hidden\" name=\"image_code\" value=\"");
      out.print(i_code );
      out.write("\"></input></td>\r\n");
      out.write("\t\t\t\t\t\t\t<td><input type=\"hidden\" name=\"u_name\" value=\"");
      out.print(x_name );
      out.write("\"></input></td>\t\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t        <td style=\"padding-right: 100px;\">\r\n");
      out.write("\t\t\t\t\t\t<div align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t<input  type=\"submit\" name=\"login\" value=\"Submit\" class=\"gradientbuttons\" onclick=\"return Changepass()\"></input>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<input  type=\"reset\" name=\"reset\" class=\"gradientbuttons\" value=\"Reset\"/>\r\n");
      out.write("\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t</div>\t\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t\t<div align=\"center\">\r\n");
      out.write("\t\t\t<table>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td style=\"color: #710069; width: 250px; left: 250px;\"> OWNER IS ");
      out.print(x_name );
      out.write("\r\n");
      out.write("\t                                                                     <br> ");
      out.print(coowner);
      out.write("\r\n");
      out.write("\t </td>\r\n");
      out.write("\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\t</form>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
