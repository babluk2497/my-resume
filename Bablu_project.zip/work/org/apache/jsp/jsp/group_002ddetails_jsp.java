package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.Image.Utility;
import com.Dao.GroupDAO;
import java.sql.*;
import java.util.*;

public final class group_002ddetails_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

int no=Utility.parse(request.getParameter("no"));

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("\r\n");
      out.write("\t<link href=\"");
      out.print(request.getContextPath() );
      out.write("/Res/CSS/style.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("\t\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath() );
      out.write("/Res/JS/style.js\"></script>\r\n");
      out.write("\t<link href=\"");
      out.print(request.getContextPath() );
      out.write("/Res/CSS/message.css\" rel=\"stylesheet\" type=\"text/css\" /> \r\n");
      out.write("</head>\r\n");
      out.write("<body onload=\"startTimer();\">\r\n");

if(no==2)
{

      out.write("\r\n");
      out.write("\r\n");
      out.write("<br>\r\n");
      out.write("\r\n");
      out.write("<h3><font color=\"#710069\">Your Group(Click on Image to Remove)</font></h3>\r\n");

		
	String user=GroupDAO.parse1(request.getAttribute("user"));
	ResultSet rs=(ResultSet)request.getAttribute("rs");
	Vector<String> v=new Vector<String>();
	if(rs!=null)
		while(rs.next())
		{
      out.write("\r\n");
      out.write("\t\t\t<a href=\"");
      out.print(request.getContextPath() );
      out.write("/CreateGroup?task=delete&grp_in=");
      out.print(rs.getString(3) );
      out.write("&grp_uid=");
      out.print(rs.getString(2) );
      out.write("\">\r\n");
      out.write("\t\t\t<img height=\"50\" width=\"50\" src=\"");
      out.print(request.getContextPath() );
      out.write("/Res/Images/user.png\" style=\"padding-top:10px\" title=\"");
      out.print(rs.getString(3) );
      out.write("\"></img></a>\r\n");
      out.write("\t\t\t<p id=\"grp\">");
      out.print(rs.getString(3) );
      out.write("</p>\t\t\r\n");
      out.write("\t\t");

		v.add(rs.getString(3));
		}
	v.add(user);
	ResultSet rs1=GroupDAO.getUsers(v);
	
      out.write("\r\n");
      out.write("\t\t<br></br>\r\n");
      out.write("\t\t<h3><font color=\"#710069\">Add to Group(Click on Image to Add)</font></h3>\r\n");
      out.write("\t");

	if(rs1!=null)
		while(rs1.next())
		{if(!GroupDAO.chkStatus(user,rs1.getString(1)).equalsIgnoreCase("pending")){
      out.write("\r\n");
      out.write("\t\t\t<a href=\"");
      out.print(request.getContextPath() );
      out.write("/SendRequest?from=");
      out.print(user );
      out.write("&to=");
      out.print(rs1.getString(1) );
      out.write("\">\r\n");
      out.write("\t\t\t<img height=\"50\" width=\"50\" src=\"");
      out.print(request.getContextPath() );
      out.write("/Res/Images/user.png\" style=\"padding-top:10px\" title=\"");
      out.print(rs1.getString(1) );
      out.write("\"></img></a>\r\n");
      out.write("\t\t\t<p id=\"grp\">");
      out.print(rs1.getString(1) );
      out.write("</p>\t\t\r\n");
      out.write("\t\t");
}}
		}

      out.write("\r\n");
      out.write("\r\n");



if(no==1)
{
      out.write("\r\n");
      out.write("\t<div class=\"error\" id=\"message\" style=\"margin-top: 30px;\">\t\r\n");
      out.write("\t\t<p>Already Friend Request Sent...!</p>\r\n");
      out.write("\t</div>\t\t\t\r\n");
}


      out.write("\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\t");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
