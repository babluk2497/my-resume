package com.data;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


import com.nitin.user.process.UserProcess;

public class ReadFile 
{
	
	
	public static boolean readfile(String fileName,String loginusername)
	{
		boolean flagdd=false;
		
		try
		{
			
					FileInputStream fstream = new FileInputStream(fileName);  		
			  		DataInputStream in = new DataInputStream(fstream);
			        BufferedReader br = new BufferedReader(new InputStreamReader(in));        
			  		String strLine;  
			  		String day="";
			  		String days="";
			  		boolean flag11=false;
			  		boolean flag=false;
			  		
			  		
			  		String distinctday="";
			  		String websites="";
			  		
			  		int uid=	UserProcess.takeuserparticularid(loginusername);
			  		System.out.println("uid is>>>>>>>>>>>>>>>>>>>>>>>>>>"+uid);
			  		
			  		while ((strLine = br.readLine()) != null)  	
			  		{
			  			int i=0;
			  			
			  			System.out.println("every line is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+strLine);
			  			String[] words=strLine.split(" ");
			  			for(String s: words)
			  			{
			  				
			  				System.out.println(" words in readfile>>>>>>>>>>>>>>>>>>>>"+s);
			  				if(s.equals("Monday,")|| s.equals("Tuesday,") || s.equals("Wednesday,")||s.equals("Thursday,")||s.equals("Friday,")||s.equals("Saturday,")||s.equals("Sunday,"))
			  				{
			  					day=s;
			  					
			  					days = day.substring(0, day.length() -1);
			  					System.out.println(" only days>>>>>>>>>>"+s);
			  					
			  				}
			  				     boolean webs=s.startsWith("www");
			  				if(webs)
			  				{ System.out.println("its came inside>>>>>>>>>>>>>>>>>>>>>>>>>>if webs>>>>>>>>>>>>>>>>>>>>>>>> ");
			  					System.out.println(" matched string is>>>>>>>>>>>>>"+s);
			  					StringBuffer sb = new StringBuffer();
			  					
			  					sb.append(s);
			  				
			  					
			  					System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>"+sb.toString().replace("'", ""));
			  					
			  					
			  					 flag11=	UserProcess.verify(days,sb.toString(),uid);
			  					System.out.println("flag11 is >>>>>>>>>>>>>>>>>>>>>>>>>>>>"+flag11);
			  					if(flag11)
			  					{
			  						
			  					}
			  					else
			  					{
			  					 flag=	UserProcess.insertnonrepeatedwebsites(days,sb.toString(),uid);
				  				System.out.println("flag value insereted verified value is >>>>>>>>>> is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+flag);
			  					}
			  					
			  				}
			  			}
			  		}
			  				
				  				
				  				if(flag)
				  				{
				  					ArrayList<String> data=new ArrayList<String>();
				  					ArrayList<String> data1=new ArrayList<String>();
				  					 data=	UserProcess.takedays(uid);
				  					
				  					for(int i1=0;i1<data.size();i1++)
				  					{
				  						StringBuffer sbb=new StringBuffer();
				  						System.out.println(data.get(i1));
				  						
				  						 distinctday=data.get(i1);
				  						
				  						
				  						System.out.println("distinct daysssss is >>>>>>>>>>>>>>>>"+distinctday);
				  						
				  					
				  						data1=	UserProcess.takewebsitesbasedonday(distinctday,uid);
				  					   for(int j1=0;j1<data1.size();j1++)
					  					{
				  						websites=data1.get(j1);
				  						System.out.println("websites is >>>>>>>>>>>>>>>>>>>>>>>>"+websites);
					  					
				  						
				  						
				  						
				  						int siteno=	UserProcess.takematchedsitenumber(websites,uid);
				  						
				  						sbb.append(siteno);
				  						sbb.append("-");
					  					}
				  					    String dataa=	sbb.toString();
				  					    System.out.println("string buffer content is  is >>>>>>>>>>>>>>>>>>>"+dataa);
				  					    
				  					//*********************************************    
				  					    
				  					  String removedcomma = dataa.substring(0, dataa.length() -1);
					  					System.out.println(" removedcomma>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+removedcomma);
				  					    
				  					  int[] intArray = new int[8];
				  					  System.out.println (removedcomma);
				  					  String ss[]=removedcomma.split("-");
				  					  for(int i=0;i<ss.length;i++)
				  					  {
				  					  System.out.println("ss arary data is >>>>>>>"+ss[i]);
				  					  
				  						  
				  					  
				  					   intArray[i]=Integer.parseInt(ss[i]);
				  						System.out.println("intarray data is >>>>>>>>>>>>>>>>>>>>>>>>>>"+intArray[i]);
				  						
				  						
				  						
				  					  
				  					  }
				  					 // StringBuffer sb1=new StringBuffer();
				  					  String dd=	Test.bubbleSort(intArray);
				  					  System.out.println("ascending order data is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+dd); 
				  					    
				  					    
				  					    
				  					    
				  					 String finaldata = dd.substring(0, dd.length() -1);
				  					 
				  					 String finaldata2="-"+finaldata;
					  					System.out.println(" finaldata>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+finaldata2);
				  					    
				  					//************************************************************	
				  						boolean insertedflag=	UserProcess.insertsessionsite(uid,distinctday,finaldata2);
				  						System.out.println(" inserted flag final is >>>>>>>>>>>>>>>>>>>>>>>"+insertedflag);
				  						if(insertedflag)
				  						{
				  							flagdd=true;	
				  						}
				  						
					  					
				  					
				  				}
				  					
				  					
				  					
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
				  				
			  				
			  		
			  			
			  			
			  		}
			  		
			  		in.close();
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
			  		
		}
		
		
		catch(Exception e)
		{
			
		}
		return flagdd;
		
	}

}
