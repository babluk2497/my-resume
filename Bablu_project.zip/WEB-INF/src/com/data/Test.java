package com.data;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;






public class Test 
{
	

	public static String readfile(String fileName) 
		
	{
		
		StringBuffer sb = new StringBuffer();
		try
		{
			
		FileInputStream fstream = new FileInputStream(fileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

		String strLine;
		
		//Read File Line By Line
		while ((strLine = br.readLine()) != null)   {
		  // Print the content on the console
			int[] intArray = new int[20];
		  System.out.println (strLine);
		  String ss[]=strLine.split("-");
		  for(int i=0;i<ss.length;i++)
		  {
		  System.out.println("ss arary data is >>>>>>>"+ss[i]);
		  if(i!=0)
		  {
			  
		  
		   intArray[i]=Integer.parseInt(ss[i]);
			System.out.println("intarray data is >>>>>>>>>>>>>>>>>>>>>>>>>>"+intArray[i]);
			
		  }
		 
		  }
	String data=	Test.bubbleSort(intArray);
	
	sb.append(data);
	sb.append("\n");
	
		}

		//Close the input stream
		br.close();
		}
	
	catch (Exception e) {
		// TODO: handle exception
	
		}


return sb.toString();
		
	}

	 public static String bubbleSort(int[] intArray)
	 {
       
        System.out.println("...............");
         int n = intArray.length;
         int temp = 0;
         StringBuffer sb = new StringBuffer();
         for(int i=0; i < n; i++)
         {
                 for(int j=1; j < (n-i); j++)
                 {
                        
                         if(intArray[j-1] > intArray[j])
                         {
                                 //swap the elements!
                                 temp = intArray[j-1];
                                 intArray[j-1] = intArray[j];
                                 intArray[j] = temp;
                         }
                        
                 }
         }
         
         for(int i1=0;i1<intArray.length;i1++)
         {
        	 
        System.out.println(""+intArray[i1]);
        
        if(intArray[i1]!=0)
        {
        	
        	sb.append(intArray[i1]);
        	sb.append("-");
        	System.out.println("stringbuffer>>>>>>>>>>"+sb.toString());
        	
        	
        }
        
       
        	 
         }
         
      return sb.toString();
         
        
	 }
	
	
	public static void main(String args[]) throws IOException 
	{
	String filename="E:\\j2ee_marchworkspace\\lofia\\sec.txt";
String data1=	Test.readfile(filename);
System.out.println("recieved data is >>>>>>>>"+data1);
	
	
	
	
	
	
try {
	File file = new File("E:\\j2ee_marchworkspace\\lofia\\outputfile");
	FileWriter fileWriter = new FileWriter(file);
	fileWriter.write(data1);
	
	fileWriter.flush();
	fileWriter.close();
} catch (IOException e) {
	e.printStackTrace();
}
	
	
}

}