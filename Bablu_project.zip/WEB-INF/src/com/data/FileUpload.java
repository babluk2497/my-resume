package com.data;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.Dao.GroupDAO;




public class FileUpload extends HttpServlet
{
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
			{
		
		
		boolean flag1111=GroupDAO.truncatetablee();
		System.out.print("truncation flag ststus is >>>>>>>>>>>>>>>>>>>>>"+flag1111);
		RequestDispatcher rd = null;
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ArrayList list=new ArrayList();
		
		HttpSession session=request.getSession(true);
		String loginusername=	(String) session.getAttribute("x_name");
		
		System.out.println("=======================");
		
		
			
		
		System.out.println("=======================");
		HttpSession hs = request.getSession();

		

		FileItemFactory fileItemFactory = new DiskFileItemFactory();
		ServletFileUpload servletFileUpload = new ServletFileUpload(fileItemFactory);
		try {

			List<File> fileItems = servletFileUpload.parseRequest(request);
			FileItem file = (FileItem) fileItems.get(0);
			
			if (file.getName().equals(""))
			{

			System.out.println("its came inside if blockkkkkkkkkkkkkkkk");
				
			RequestDispatcher rd1=request.getRequestDispatcher("/jsp/tellyouself.jsp?no=10");
			rd1.forward(request, response);
				
				
				
			}
			
			
			
			else
			{
			String fileName = request.getRealPath("") + "/upload/"+ file.getName();
			
			System.out.println("filename is >>>>>>>>>>>>>>>>>>>"+fileName);
			
			OutputStream outputStream = new FileOutputStream(fileName);
			InputStream inputStream = file.getInputStream();

			int readBytes = 0;
			byte[] buffer = new byte[10000];
			while ((readBytes = inputStream.read(buffer, 0, 10000)) != -1)
			{
				outputStream.write(buffer, 0, readBytes);
			}
			outputStream.close();
			inputStream.close();
			
			
			if (file.getName() != null)
			{

				
				boolean flag = ReadFile.readfile(fileName,loginusername);
				
				System.out.println(" flag in fileupload>>>>>>>>>>>>>>>>>>>>>>"+flag);
				if(flag)
				{
				
					
					System.out.println("its came inside if block>>>>>>");
					RequestDispatcher rd1=request.getRequestDispatcher("/jsp/tellyouself.jsp?no=7");
					rd1.forward(request, response);
				}else
				{
					System.out.println("its came insideelse block>>>>>>");
					RequestDispatcher rd1=request.getRequestDispatcher("/jsp/tellyouself.jsp?no=8");
					rd1.forward(request, response);
				}
				
				
				
		}
		}}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
	}

	
}