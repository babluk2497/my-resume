package com.Image;

import java.awt.*;
import java.awt.image.*;
import java.io.*
;

import javax.imageio.*;

public class ImageTest 
{
	private static final int IMG_WIDTH = 400;
	private static final int IMG_HEIGHT = 200;
 
	
	 
	    public static BufferedImage resizeImage(BufferedImage originalImage, int type)
	    {
			BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
			g.dispose();
		 
			return resizedImage;
	    }
	 
	    public static BufferedImage resizeImageWithHint(BufferedImage originalImage, int type)
	    {
	 
			BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
			g.dispose();	
			g.setComposite(AlphaComposite.Src);
		 
			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			g.setRenderingHint(RenderingHints.KEY_RENDERING,
			RenderingHints.VALUE_RENDER_QUALITY);
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		 
			return resizedImage;
	    }	
    
}
