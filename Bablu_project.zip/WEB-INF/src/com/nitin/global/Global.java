
package com.nitin.global;


public interface Global 
{
	// Database Related Constants
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";	
	public static final String JDBC_HOST_URL_WITH_DBNAME = "jdbc:mysql://localhost:3306/my_privacy_my_decesion";
	public static final String DATABASE_USERNAME = "root";
	public static final String DATABASE_PASSWORD = "admin";
}
