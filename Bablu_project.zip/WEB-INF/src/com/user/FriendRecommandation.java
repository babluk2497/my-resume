package com.user;

import java.io.IOException;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.GroupDAO;
import com.Dao.Utility;
import com.Dao.*;


//import com.mysql.jdbc.ResultSet;

public class FriendRecommandation extends HttpServlet{
		
		protected void doGet(HttpServletRequest req, HttpServletResponse resp)
				throws ServletException, IOException {
			
			ArrayList<String> data=new ArrayList<String>();
			ArrayList< String> similarfriend=new ArrayList<String>();
			
			RequestDispatcher rd=null;
			
			 String status="";
			 String aaa="";
			 int tvalue1=0;
			 double tvalue=0.0;
			try{
				boolean flag1111=GroupDAO.truncatetable1();
				System.out.print("truncation flag ststus is >>>>>>>>>>>>>>>>>>>>>"+flag1111);
				
				
				

				String ontologypattern_weightage=Utility.getPro("ontologypattern_weightage");
				System.out.println("ontologypattern_weightage>>>>>>>>>>>>>>>>>>>>>>>>>>"+ontologypattern_weightage);
				double ovalue = Double.parseDouble(ontologypattern_weightage);
				
				
				String browsingpattern_weightage=Utility.getPro("browsingpattern_weightage");
				System.out.println("browsingpattern_weightage>>>>>>>>>>>>>>>>>>>>>>>>>>"+browsingpattern_weightage);
				double bvalue = Double.parseDouble(browsingpattern_weightage);
				
				
				
				String areapattern_weightage=Utility.getPro("areapattern_weightage");
				System.out.println("areapattern_weightage>>>>>>>>>>>>>>>>>>>>>>>>>>"+areapattern_weightage);
				double avalue = Double.parseDouble(areapattern_weightage);
				
				
				String hobbypattern_weightage=Utility.getPro("hobbypattern_weightage");
				System.out.println("hobbypattern_weightage>>>>>>>>>>>>>>>>>>>>>>>>>>"+hobbypattern_weightage);
				double hvalue = Double.parseDouble(hobbypattern_weightage);
				
				
				String total_weightage=Utility.getPro("total_weightage");
				System.out.println("total_weightage>>>>>>>>>>>>>>>>>>>>>>>>>>"+total_weightage);
			tvalue = Double.parseDouble(total_weightage);
				/*Double d = new Double(tvalue);
				 tvalue1 = d.intValue();*/
				
				String submit=req.getParameter("action");
				
				HttpSession session=req.getSession(false);
				
				String name=(String)session.getAttribute("x_user_id");
				
				System.out.println("user name is" +name);
				
				int userid=GroupDAO.getparticularuserid(name);
				
				
				List<String> ontologypat = new ArrayList<String>();
				List<String> browsepat = new ArrayList<String>();
				List<String> placepat = new ArrayList<String>();
				List<String> hobbylist = new ArrayList<String>();
				List<String> hobbylistofnonfriends = new ArrayList<String>();
				
				System.out.println("particular userid is>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+userid);
				
				
				
				
				String username=""+userid;
				
				
				
				ArrayList<String> al3=new ArrayList<String>();
				List<String> comparingList = new ArrayList<String>();
				List<String> comparingList1 = new ArrayList<String>();
				List<String> comparingList2 = new ArrayList<String>();
				List<String> comparingList3 = new ArrayList<String>();
				List<String> comparingList4 = new ArrayList<String>();    
				  
				
				
			    ArrayList<String> allusers=GroupDAO.getusersdetails();
			    
				System.out.println("all users are>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+allusers);
				
			    
			    
				ArrayList<String> frienddetails=GroupDAO.getfriendsdetails(name);
				
				System.out.println("already friends to user are>>>>>>>>>>>>>>>>>>>>>>>>>"+frienddetails);
				
				
				HttpSession session1=req.getSession(false);
				
				String name1=(String)session1.getAttribute("x_user_id");
				System.out.println("login user name is>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" +name1);
				
				int userid1=GroupDAO.getparticularuserid(name1);
				
				System.out.println("particular userid is>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+userid);
				
				
				
				
			
				
				for (int a = 0; a < allusers.size(); a++) {
					
			        comparingList.add(allusers.get(a));
			      

			    }
			
			    for (int counter = 0; counter < allusers.size(); counter++) {
			        if (!frienddetails.contains(allusers.get(counter))) {
			            comparingList1.add(allusers.get(counter));
			        }
			    }

			    System.out.println("compared list nonfriends to login user are  is >>>>>>>>>>>>>>>>>>>>>>>>>>are>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+comparingList1);
			  
			    for (int a = 0; a < comparingList1.size(); a++)
			    {
			        comparingList2.add(GroupDAO.getuserid1(comparingList1.get(a).toString()));
			        
			       System.out.println("nonfriends >>>>>>>>>>user id is issssssssssss"+comparingList2.get(a));
			    
			    }
		
			    
			//...............................ontologypattern........................................................  
			    
			    
			    
			    String ontologypattern=GroupDAO.getparticularuserontologypattern(name);
				System.out.println("ontologypattern  of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+ontologypattern);
			    
			    String[] ontologypattern1=ontologypattern.split("-");
			    
			    for(int i9=0;i9<ontologypattern1.length;i9++)
				{
					
			    	ontologypat.add(ontologypattern1[i9]);
					
				
				}
				System.out.println("ontologypat  of particular user in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+ontologypat);
				
				System.out.println("ontologypat  of particular user size in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+ontologypat.size());
				int loginusersize=ontologypat.size();
			    
				 for(int j=0;j<comparingList1.size();j++)
				    {
					 int count=0;
					 
			    	
			    	String nonfroendp=GroupDAO.getparticularuserontologypattern(comparingList1.get(j));
					System.out.println("ontologypat of nonfriends user>>>>>>>>>>>>>>>>>>>>>>>>>"+nonfroendp);
					String[] ont=nonfroendp.split("-");
					
					
					
					
					
					if(ontologypat.size()>=ont.length)
					{
						
						
						for(int i7=0;i7<ont.length;i7++)
						{
						
							
							 
							 
							 
							 for(int i8=0;i8<ontologypat.size();i8++)
							 {
							 
							 if(ontologypat.get(i8).contains(ont[i7]))
						       {
								 
							       count++;
						           System.out.println("=======count of nonfriends prof user=============="+count);
						       }
							 }
				    	
				    	
						}
						
						
						
					}
					else
					{
						
						
						for(int i7=0;i7<ontologypat.size();i7++)
						{
							
							
							 for(int i8=0;i8<ont.length;i8++)
							 {
							 
							 if(ontologypat.get(i7).contains(ont[i8]))
						       {
								 
							       count++;
						           System.out.println("=======count of nonfriends ontologypat user=============="+count);
						           
						         
										
						       }
							 }
					
						}
						
						
						
					}
					
					
					int uid=GroupDAO.getparticularuserid(comparingList1.get(j));
					String uid1=""+uid;
					
					if(!comparingList1.get(j).equals(name))
					{
						
						System.out.println("count inside if loop>>>>>>>>>>>>"+count);
						System.out.println("loginusersize>>>>>>>>>>"+loginusersize);
						
						System.out.println("ovalue>>>>>>>>>"+ovalue);
						
						
						  double ontologyweightpuser=	((double)count/(double)loginusersize)*(ovalue/100.0);
						 
							System.out.println("ontologyweightpuser>>>>>>>>>>>>>>"+ontologyweightpuser);
							
							String total2 = String.valueOf(ontologyweightpuser);
						
					   boolean flag77=GroupDAO.insertontpatt(uid1,total2);
					   
					   System.out.println("ontpattern insertion is >>>>>>>>>>>"+flag77);
					}
					
				
			    
			    
				    }
			    
			    
			    
			    
			    
			    
			    
			  //...............................ontologypattern....Ends.....................................................      
			    
				 //...............................browsinghistory pattern ....Starts.....................................................    
				 
				 
				 
				  
				    
				    String paruserfrequentset=GroupDAO.Getparfrequentset(userid);
					System.out.println("paruserfrequentset of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+paruserfrequentset);
				    
				    String[] paruserfrequentset1=paruserfrequentset.split(",");
				    
				    for(int i9=0;i9<paruserfrequentset1.length;i9++)
					{
						
				    	browsepat.add(paruserfrequentset1[i9]);
						
					
					}
					System.out.println("browsepat  of particular user in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+browsepat);
					
					System.out.println("browsepat  of particular user size in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+browsepat.size());
					int browsepatsize=browsepat.size();
					String nonfroenbrowsedata="";
					
					 for(int j=0;j<comparingList2.size();j++)
					    {
						 int count=0;
						
				       nonfroenbrowsedata=GroupDAO.getfrequentsets(comparingList2.get(j));
						System.out.println("nonfroenbrowsedata nonfriends user>>>>>>>>>>>>>>>>>>>>>>>>>"+nonfroenbrowsedata);
						
						   
						String[] browse=nonfroenbrowsedata.split(",");
						
						
						
						
						
						if(browsepat.size()>=browse.length)
						{
							
							
							
							for(int i7=0;i7<browse.length;i7++)
							{
							
								
								 
								 
								 
								 for(int i8=0;i8<browsepat.size();i8++)
								 {
									 
									 if(browsepat.get(i8).equals("0"))
									 {
										 
									 }
									
								 
									 else	 if(browsepat.get(i8).contains(browse[i7]))
							       {
									 
								       count++;
							           System.out.println("=======count of nonfriends browse user=============="+count);
							       }
								 }
					    	
					    	
							}
							
							
							
						}
						else
						{
							
							
							for(int i7=0;i7<browsepat.size();i7++)
							{
								
								
								 for(int i8=0;i8<browse.length;i8++)
								 {
								 
								 if(browsepat.get(i7).contains(browse[i8]))
							       {
									 
								       count++;
							           System.out.println("=======count of nonfriends browse user=============="+count);
							           
							         
											
							       }
								 }
						
							}
							
							
							
						}
						
						
						int uid=GroupDAO.getparticularuserid(comparingList1.get(j));
						String uid1=""+uid;
						
						if(!comparingList1.get(j).equals(name))
						{
							
							System.out.println("count inside if loop>>>>>>>>>>>>"+count);
							System.out.println("browsepatsize>>>>>>>>>>"+browsepatsize);
							
							System.out.println("bvalue>>>>>>>>>"+bvalue);
							
							
							  double browseweightpuser=	((double)count/(double)browsepatsize)*(bvalue/100.0);
							 
								System.out.println("browseweightpuser>>>>>>>>>>>>>>"+browseweightpuser);
								
								String totalbrowse = String.valueOf(browseweightpuser);
								
								boolean flag777=GroupDAO.updatefriendrecomand2(uid1,totalbrowse);
							
						
						   System.out.println("browsepattern updation is >>>>>>>>>>>"+flag777);
						}
						
					
				    
				    
					    }
				    
				    
				 
				 
				 
				 
				 //...............................browsinghistory pattern ....ends.....................................................   
					 
					 
					 
					 //hobbypattern starts..............................................................................................
					 
					 
					 
					 String hobby=GroupDAO.getparticularuserhobby(name);
						System.out.println("hobby of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+hobby);
						
						String[] hobbies=hobby.split(",");
						
						for(int i5=0;i5<hobbies.length;i5++)
						{
							
							hobbylist.add(hobbies[i5]);
							
						
						}
						System.out.println("hobbylist  of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+hobbylist);
						
						System.out.println("hobbylist size  of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+hobbylist.size());
						
						int hobbysizeloginuser=hobbylist.size();
						
						
						
						
					    for(int j=0;j<comparingList1.size();j++)
					    {
					    	
					    	 
					    	  
					    	int count=0;
					    	System.out.println("comparedlist1 size in hobbies>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+comparingList1.get(j));
					    	String Nonfrindshobbies=GroupDAO.getparticularuserhobby(comparingList1.get(j));
							System.out.println("hobby of nonfriends user>>>>>>>>>>>>>>>>>>>>>>>>>"+Nonfrindshobbies);
							
							
							String[] nonfriendshobbies=Nonfrindshobbies.split(",");
							
							if(hobbylist.size()>=nonfriendshobbies.length)
							{
								
								
								for(int i7=0;i7<nonfriendshobbies.length;i7++)
								{
									
									
									 for(int i8=0;i8<hobbylist.size();i8++)
									 {
									 
									 if(hobbylist.get(i8).contains(nonfriendshobbies[i7]))
								       {
										 
									       count++;
								           System.out.println("=======count of nonfriends user=============="+count);
								       }
									 }
							
								}	
								
								
								
							}
							else
							{
								
								
								for(int i7=0;i7<hobbylist.size();i7++)
								{
									
									
									 for(int i8=0;i8<nonfriendshobbies.length;i8++)
									 {
										 System.out.println("=======comparision=============="+hobbylist.get(i7)+"====compares==="+nonfriendshobbies[i8]);
									 
									 if(hobbylist.get(i7).contains(nonfriendshobbies[i8]))
								       {
										 
									       count++;
								           System.out.println("=======count of nonfriends user=============="+count);
								       }
									 else
										 
									 {
										 System.out.println("======elsepart=count of nonfriends user=============="+count);
									 }
									 }
							
								}
								
								
								
								
								
								
							}
							
							
							
							
							
							
							
						
							
						int uid=GroupDAO.getparticularuserid(comparingList1.get(j));
							String uid1=""+uid;
							
							if(!comparingList1.get(j).equals(name))
							{
								
								
								

								System.out.println("count inside if loop>>>>>>>>>>>>"+count);
								System.out.println("hobbysizeloginuser>>>>>>>>>>"+hobbysizeloginuser);
								
								System.out.println("hvalue>>>>>>>>>"+hvalue);
								
								
								  double hobbyweightpuser=	((double)count/(double)hobbysizeloginuser)*(hvalue/100.0);
								  
								double roundedvalue=  Math.round (hobbyweightpuser * 10000.0) / 10000.0; 
								 
									System.out.println("roundedvalue>>>>>>>>>>>>>>"+roundedvalue);
									
									String totalhobby = String.valueOf(roundedvalue);
									
									boolean flag777=GroupDAO.updatefriendrecomand3(uid1,totalhobby);
								
							
							   System.out.println("browsepattern updation is >>>>>>>>>>>"+flag777);
								
								
								
								
								
								
							
							}
							
						
					    }
					    
					 
					 //hobbypattern Ends..............................................................................................
					    
					    //place Starts..............................................................................................
					    
					    
					    
					    String paruseruserplace=GroupDAO.Getparticularuserplace(name);
						System.out.println("paruseruserplace of particular user>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+paruseruserplace);
					    
					   
							
						placepat.add(paruseruserplace);
							
						
						
						System.out.println("placepat  of particular user in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+placepat);
						
						System.out.println("placepat  of particular user size in list >>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+placepat.size());
						int placepatsize=placepat.size();
						String nonfriendpat="";
						
						 for(int j=0;j<comparingList1.size();j++)
						    {
							 int count=0;
							
					       nonfriendpat=GroupDAO.Getparticularuserplace(comparingList1.get(j));
							System.out.println("nonfriendpat nonfriends user>>>>>>>>>>>>>>>>>>>>>>>>>"+nonfriendpat);
							
							   
							
							
							
							
							
							
									 
									 
									 
									
									 
									 if(paruseruserplace.equals(nonfriendpat))
								       {
										 
									       count++;
								           System.out.println("=======count of nonfriends place user=============="+count);
								       }
									 
									 else
									 {
										 count=0;
										 
										 
									 }
									
						    	
						    	
								
								
								
								
							
							
							
							
							int uid=GroupDAO.getparticularuserid(comparingList1.get(j));
							String uid1=""+uid;
							
							if(!comparingList1.get(j).equals(name))
							{
								
								System.out.println("count inside if loop>>>>>>>>>>>>"+count);
								System.out.println("placepatsize>>>>>>>>>>"+placepatsize);
								
								System.out.println("avalue>>>>>>>>>"+avalue);
								
								
								  double placeweightpuser=	((double)count/(double)placepatsize)*(avalue/100.0);
								 
									System.out.println("placeweightpuser>>>>>>>>>>>>>>"+placeweightpuser);
									
									String totalplace = String.valueOf(placeweightpuser);
									
									boolean flag777=GroupDAO.updatefriendrecomand5(uid1,totalplace);
								
							
							   System.out.println("browsepattern updation is >>>>>>>>>>>"+flag777);
							}
							
						    }
					    
					    
						  
					    
					    
					 
					 
					 
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    
					    //place Ends.............................................................................................. 
			
			    
			    
			    
			
			
			}
			
				catch (Exception e)
			
			{


			}
			
	
		ResultSet  rs=GroupDAO.getusersfriendrecomend();
		
		
		
		try
		{
			while(rs.next())
			{
				double ontpatt=Double.parseDouble(rs.getString(3));
				
				double browsepatt=Double.parseDouble(rs.getString(4));
				double hobbypattern=Double.parseDouble(rs.getString(5));
				double placepatt=Double.parseDouble(rs.getString(6));
				
				
				double sum=ontpatt+browsepatt+hobbypattern+placepatt;
				
				double totaluserweitage=sum*100;
				/*Double d = new Double(totaluserweitage);
				int finaluserweitage = d.intValue();*/
				
				
				
				double roundedvalue1=  Math.round (totaluserweitage * 10000.0) / 10000.0; 
				
				
				String totaluserweitage11 = String.valueOf(roundedvalue1);
				boolean flag=GroupDAO.updatetotalWeightage(rs.getInt(2), totaluserweitage11);
				System.out.println("final total weitage inserted value flag "+flag);
				
			if(flag==true)
				{
					
				if(roundedvalue1>=tvalue)
				{
					System.out.println("user id is ---------------------------------------"+rs.getInt(2));
					String similarfriends=GroupDAO.getusernamesofsimilarfriends(rs.getInt(2));
					System.out.println("similar friends are-------------------------------------------"+similarfriends);
					similarfriend.add(similarfriends);
					
					
				}
			}}
			
			req.setAttribute("similarfriend", similarfriend);
			
	        rd=req.getRequestDispatcher("/jsp/Similarfriends.jsp?no=2");
			rd.forward(req, resp);
		
		}
		
		
		
		catch (Exception e)
		{
			e.printStackTrace();
		}
	
		
	
		
	}
		
		
		

}
