package com.user;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.Dao.ImageDAO;



public class Add extends HttpServlet
{

	@SuppressWarnings({ "deprecation", "unused" })
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
			{
		LinkedHashMap<String, String> data = new LinkedHashMap<>();	
		
		RequestDispatcher rd = null;
		String NA="-NA-";
		
		
		String msg="";
		
		boolean flagff=false;
	
		
	String submit="";
		//String fileName =null;
		String[] name = new String[50];
		int i=0;
		String root = null;
		File uploadedFile = null;
		ArrayList<String> list = new ArrayList<String>();
		
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		
		String state="";
		
		
		
		try {

			System.out.println("its came inside Add>>>>>>>>>>>>>>>>>>>>>>>>");
			FileItemFactory fileItemFactory = new DiskFileItemFactory();
			ServletFileUpload servletFileUpload = new ServletFileUpload(fileItemFactory);
			List fileItems = servletFileUpload.parseRequest(request);

			
			FileItem file = (FileItem) fileItems.get(0);
			

			
			
			String fileName = request.getRealPath("") + "/Tellabouturself/"+ file.getName();
			
			OutputStream outputStream = new FileOutputStream(fileName);
			InputStream inputStream = file.getInputStream();

			int readBytes = 0;
			byte[] buffer = new byte[10000];
			while ((readBytes = inputStream.read(buffer, 0, 10000)) != -1)
			{
				outputStream.write(buffer, 0, readBytes);
			}
			outputStream.close();
			inputStream.close();
			
			
			/*if (file.getName() != null)
			{

				
				String s = ReadFile.readfile(fileName);
				
				System.out.println(" every word is >>>>>>>>>>>>>>>>>>>>>>>"+s);
				
				
				
		}*/
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			/*try{
				
				System.out.println("its came inside Add>>>>>>>>>>>>>>>>>>>>>>>>");
				FileItemFactory fileItemFactory = new DiskFileItemFactory();
				ServletFileUpload servletFileUpload = new ServletFileUpload(fileItemFactory);
				List fileItems = servletFileUpload.parseRequest(request);
				
				
				
				
				Iterator iterator = fileItems.iterator();
				int s=fileItems.size();
				for(int j=0;j<s;j++)
				{
					FileItem one =(FileItem)fileItems.get(j);
					one.getFieldName();
					String str=one.getContentType();
					
				
					
					if(str=="application/octet-stream")
					{
						
						
					}
				
					
						 
						  data.put(one.getFieldName().toString(), one.getString().toString());
						
						
						 if(data.get(one.getFieldName().toString()).isEmpty() || data.get(one.getFieldName().toString())==null || data.get(one.getFieldName().toString()).equals("")||data.get(one.getFieldName().toString()).equals("Select") || data.get(one.getFieldName().toString()).equals("null"))
						 {
							 data.put(one.getFieldName().toString(), NA);
						 }
						
					
					 
				}
				submit = (String) data.get("submit");
			
				msg = (String) data.get("msg");
				
				
				
				
		
				
				
				System.out.println("its came inside Upload>>>>>>>>>>>>>>>>");

				while (iterator.hasNext())
				{
					FileItem item = (FileItem) iterator.next();
					long size=item.getSize();
			
					
						String format = "none";
						fileName = item.getName();
					
			//root = request.getContextPath()+("/UploadedFiles");
			
			root = request.getRealPath("/UploadedFiles");
					

                         File ff=new File(root);
                         if (!ff.exists()) 
                              {
                                ff.mkdirs();
                              }
						
						
						int index = fileName.lastIndexOf(".");
						if(index > 0)
						{
						               format = fileName.substring(index+1);
						               format = format.toLowerCase();
						}
						
						
						
						uploadedFile = new File(root +"/"+fileName);
						
					
						item.write(uploadedFile);
						
						boolean flag=FtpUrlUpload.ftpfileupload(Global.ftpUrl,Global.host,Global.company_user, Global.company_pass,Global.company_root_dir, root+"/"+filenametostore, filenametostore, Global.BUFFER_SIZE);
						if(flag)
						{
							File file = new File( root+"/"+filenametostore);
							 boolean blnDeleted=false;
							  blnDeleted = file.delete();
						}
						
						String dir="";
				
		
					}	
	
				
				

			}catch (Exception e) 
			{
				e.printStackTrace();
			}*/
			
			
			
			
			
		/*	try
			{
					
						    
						boolean flag=false;
						
						if(submit.equals("Save"))
						{
							System.out.println("its came inside save block");
							

							HttpSession session=request.getSession(true);
							
						
						System.out.println("text messge is >..........."+msg);
					    String loginusername=	(String) session.getAttribute("x_name");

					     String textfilename=loginusername+"."+"txt";


						 try{
							    // Create file 
							    FileWriter fstream = new FileWriter(request.getRealPath("")+"\\Tellabouturself\\"+textfilename);
							        BufferedWriter out = new BufferedWriter(fstream);
							    out.write(msg);
							    //Close the output stream
							    out.close();
							    String fileName1 = request.getRealPath("")+"\\Tellabouturself\\"+textfilename;
							    String readeddata = Tellaboutyourself.readfile(fileName1);
							    System.out.println(" readed  is >>>>>>>>>>>>>>>>>>"+readeddata);
							    String data3=readeddata.toLowerCase();
								System.out.println("**Lower case Covert File :"+data3);
								
								FileWriter fooWriter = new FileWriter(fileName1, false); // true to append  & false to overwrite.					                                                
								fooWriter.write(data3);
								fooWriter.close();	
						 
								
								String data2=Program.filterwords(data3);//(fileName);
								
								
								
								System.out.println("**unnneccesary data removed>>>>>>>>>>>>:***\n"+data2);
								FileWriter foWriter = new FileWriter(fileName1, false); // true to append
					            // false to overwrite.
					             foWriter.write(data2);
					             foWriter.close();
								
								
					         	String dat = TextSearch.text_Search(fileName1);
								
								 System.out.println("List Of words  is :"+dat);
								
								 ArrayList key_data = TextSearch.text_filter(dat);
								   
								   System.out.println("filtered_data is>>>>>>>>>>>>>> :"+key_data);
								   String removedbrace = key_data.toString().replace("[", "").replace("]", "");
								   System.out.println("removed data is >>>>>>>>>>>"+removedbrace);
								   
								   
								   StringBuffer sb11=new StringBuffer();
								   for(int i1=0;i1<key_data.size();i1++)
								   {
									  
									String word=(String) key_data.get(i1);
									System.out.println("one by one word is >>>>>>>>>>>>>"+word);
									 int ontpatt= ImageDAO.takeontologypattern(word);
									 
									 if(ontpatt==0)
									 {
										 
									 }
									 else
									 {
									 sb11.append(ontpatt);
									 sb11.append("-");
									String ontologypattern= sb11.toString();
									
								
									System.out.println("final ontology patetrn is >>>>>>>>>>>>>>>>>>"+ontologypattern);
									 
									 boolean  flagvalue= ImageDAO.insertontologypattern(removedbrace,ontologypattern,loginusername);
									 System.out.println("flsgvalue is >>>>>>>>>>>>>>>>>>>>>>>"+flagvalue);
									
									
									
								   }
								   }
								   
								   
								   
						 
						 }
						 
						 catch (Exception e){//Catch exception if any
							      System.err.println("Error: " + e.getMessage());
							    }
						
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
						
						}
						
						
						
					}
			catch(Exception e)
			{
				e.printStackTrace();
			}*/
		
		
			
		}
	
	
	
	
	
	public static String readfile(String fileName)
	{	StringBuffer sb = new StringBuffer();
		boolean flag=false;
		try
		{
		
	
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			   //get current date time with Date()
			   Date date = new Date();
			   System.out.println(dateFormat.format(date));
			  
					FileInputStream fstream = new FileInputStream(fileName);  		
			  		DataInputStream in = new DataInputStream(fstream);
			        BufferedReader br = new BufferedReader(new InputStreamReader(in));        
			  		String strLine;  		
			  		while ((strLine = br.readLine()) != null)  	
			  		{
			  			
			  			System.out.println("string line is>>>>>>>>>>>>>"+strLine);
			  			String[] words=strLine.split(" ");
			  			for(String s: words)
			  			{
			  				sb.append(s);
			  				sb.append(" ");
			  				//System.out.println("aaaaaaaaaaaaa>>>>>>>>>>>>>>>>>"+sb.toString());
			  				
			  			}
			  		
			  			 //flag= AdminDAO.insertshoppingdetails(dateFormat.format(date),sb.toString());
			  			System.out.println("flag value is >>>>>>>>>>>"+flag);
			  		}
			  		
			  		in.close();
		}
		catch(Exception e)
		{
			System.out.println("ERROR : in ReadFile Class===>"+e);
		}
		
		return sb.toString().trim();
	}
	
	
	
	
	
	
	
	
	
	
	
}

