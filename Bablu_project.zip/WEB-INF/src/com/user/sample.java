package com.user;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class sample
{
	
	public static String frequent(String freqpath)
	{
		String item=null;
		
	//	String freqPath=request.getRealPath("")+"\\Data\\Freq_Sets\\Freq_db_horizontal1.dat";
		try (BufferedReader br = new BufferedReader(new FileReader(freqpath)))
		{
          ArrayList<String> data=new ArrayList<String>();
  
			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
				data.add(sCurrentLine);
			}
			int size=data.size();
			
			 item=data.get(size-1);
			System.out.println("-------------------ITEM"+item);
			

		} catch (IOException e) {
			e.printStackTrace();
		}
		return item;
		
	}

	/*public static void main(String[] args) {

		try (BufferedReader br = new BufferedReader(new FileReader("D:\\Freq_db_horizontal1.dat")))
		{
  ArrayList<String> data=new ArrayList<String>();
  
			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
				data.add(sCurrentLine);
			}
			int size=data.size();
			
			String item=data.get(size-1);
			System.out.println("-------------------ITEM"+item);
			

		} catch (IOException e) {
			e.printStackTrace();
		} */

	}

