package com.algorithm;

		import javax.imageio.ImageIO;
		import java.awt.image.BufferedImage;
		import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.awt.*;

		public class SplitImageToChunks
		{
			
			  public static boolean SplituploadedImage(String inputFile, String outputFile) throws IOException
			  {
				  //String path="E:/WORKSPACES/Workspace/PassBYOP1.0/PasswordImages/Image1/Imageblocks/";
	               String path2=outputFile;
			        File file = new File(inputFile); // I have bear.jpg in my working directory
			        FileInputStream fis = new FileInputStream(file);
			        BufferedImage image = ImageIO.read(fis); //reading the image file

			        int rows = 3; //You should decide the values for rows and cols variables
			        int cols = 3;
			        int chunks = rows * cols;
			        
			       
			        
			       
			       
			        int count = 0;
			        BufferedImage imgs[] = new BufferedImage[chunks]; //Image array to hold image chunks
			        
			        ArrayList<String> list=new ArrayList<String>();
			        for (int x = 0; x < rows; x++)
			        {
			            for (int y = 0; y < cols; y++)
			            {
			            	
			            	 int widtharr[]={160,130,100};
						        int hight[]={30,75,50};
			            	Random random = new Random();
			            	int indexToGetwidth= random.nextInt(widtharr.length);
			            	int indexToGethight = random.nextInt(hight.length);
			                //Initialize the image array with image chunks
			            	//x=random.nextInt(rows);
			            	//y=random.nextInt(cols);
			            	
			            	 int chunkWidth=widtharr[indexToGetwidth];
			            	 int chunkHeight=hight[indexToGethight];
			                imgs[count] = new BufferedImage(chunkWidth, chunkHeight, image.getType());
	                      
	                        int m=x+1;
	                        int n=y+1;
			                list.add(m+"_"+n);
			                // draws the image chunk
			                Graphics2D gr = imgs[count++].createGraphics();
			                
			              
			                gr.drawImage(image, 0, 0, chunkWidth, chunkHeight, chunkWidth * y, chunkHeight * x, chunkWidth * y + chunkWidth, chunkHeight * x + chunkHeight, null);
			                gr.dispose();
			            }
			        }
			        System.out.println("Splitting done");
	                 int j=0;
			        //writing mini images into image files
			        for (int i = 0; i < imgs.length; i++) 
			        {
			           j=i+1;
			        	
			           // ImageIO.write(imgs[i], "jpg", new File(path+"img" + j + ".jpg"));
			            ImageIO.write(imgs[i], "jpg", new File(path2+"//"+"img" +list.get(i) + ".jpg"));
			        }
			        System.out.println("Mini images created");
				return true;
				  
			  }
			
			
			
			
			
		    public static void main(String[] args) throws IOException
		    {
		    	SplitImageToChunks.SplituploadedImage("bharath.jpg", "D:/temp");
		    }
		

	}


