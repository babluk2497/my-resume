/*
SQLyog - Free MySQL GUI v5.19
Host - 5.0.15-nt : Database - my_privacy_my_decesion
*********************************************************************
Server version : 5.0.15-nt
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `my_privacy_my_decesion`;

USE `my_privacy_my_decesion`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `adminlogin` */

DROP TABLE IF EXISTS `adminlogin`;

CREATE TABLE `adminlogin` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `adminid` varchar(20) NOT NULL,
  `phone` varchar(15) default NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`,`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `adminlogin` */

insert into `adminlogin` (`id`,`name`,`password`,`adminid`,`phone`,`email`) values (1,'admin','admin123','admin','9887878787','adminn123@gmail.com');

/*Table structure for table `imagecount` */

DROP TABLE IF EXISTS `imagecount`;

CREATE TABLE `imagecount` (
  `s_no` int(3) NOT NULL auto_increment,
  `Count1` int(4) default NULL,
  PRIMARY KEY  (`s_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `imagecount` */

insert into `imagecount` (`s_no`,`Count1`) values (1,2);

/*Table structure for table `m_group` */

DROP TABLE IF EXISTS `m_group`;

CREATE TABLE `m_group` (
  `id` int(5) NOT NULL auto_increment,
  `grp_uid` varchar(50) default NULL,
  `grp_in` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_group` */

insert into `m_group` (`id`,`grp_uid`,`grp_in`) values (1,'rajan','bharath');
insert into `m_group` (`id`,`grp_uid`,`grp_in`) values (2,'bharath','rajan');

/*Table structure for table `m_image` */

DROP TABLE IF EXISTS `m_image`;

CREATE TABLE `m_image` (
  `i_code` int(11) NOT NULL auto_increment,
  `u_code` int(11) NOT NULL,
  `i_file_name` varchar(100) NOT NULL,
  `img_tag_date` datetime default NULL,
  PRIMARY KEY  (`i_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_image` */

insert into `m_image` (`i_code`,`u_code`,`i_file_name`,`img_tag_date`) values (1,2,'test.jpg','2018-05-09 13:04:59');
insert into `m_image` (`i_code`,`u_code`,`i_file_name`,`img_tag_date`) values (2,2,'test.jpg','2018-05-09 13:05:49');
insert into `m_image` (`i_code`,`u_code`,`i_file_name`,`img_tag_date`) values (3,2,'test.jpg','2018-05-09 13:07:15');

/*Table structure for table `m_request` */

DROP TABLE IF EXISTS `m_request`;

CREATE TABLE `m_request` (
  `id` int(5) NOT NULL auto_increment,
  `req_from` varchar(50) default NULL,
  `req_to` varchar(50) default NULL,
  `req_status` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_request` */

insert into `m_request` (`id`,`req_from`,`req_to`,`req_status`) values (1,'bharath','rajan','accepted');

/*Table structure for table `m_status` */

DROP TABLE IF EXISTS `m_status`;

CREATE TABLE `m_status` (
  `s_no` int(20) NOT NULL auto_increment,
  `u_name` varchar(50) default NULL,
  `tot_req` int(20) default '0',
  `acc_req` int(20) default '0',
  `rej_req` int(20) default '0',
  `pending` int(20) default '0',
  `rej_ratio` varchar(20) default '0',
  `pen_ratio` varchar(20) default '0',
  `total_ratio` varchar(20) default '0',
  `u_status` varchar(20) default 'general',
  PRIMARY KEY  (`s_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_status` */

insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (1,'bharath',4,1,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (2,'RAJAN',2,1,0,1,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (3,'bharath',4,1,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (4,'bharath',4,1,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (5,'rajan',2,1,0,1,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (6,'saleem',1,1,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (7,'ranjith',0,0,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (8,'amith',0,0,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (9,'bharath',4,1,0,0,'0','0','0','general');
insert into `m_status` (`s_no`,`u_name`,`tot_req`,`acc_req`,`rej_req`,`pending`,`rej_ratio`,`pen_ratio`,`total_ratio`,`u_status`) values (10,'rajan',0,0,0,0,'0','0','0','general');

/*Table structure for table `m_tag` */

DROP TABLE IF EXISTS `m_tag`;

CREATE TABLE `m_tag` (
  `tag_no` int(20) NOT NULL auto_increment,
  `i_code` int(15) default NULL,
  `u_code` int(15) default NULL,
  `tag` varchar(500) default NULL,
  `time` varchar(50) default NULL,
  PRIMARY KEY  (`tag_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_tag` */

insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (1,1,1,'ds','17-04-2018 15:36:42');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (2,1,2,'vdvd','17-04-2018 15:38:14');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (3,2,1,'hmnh','17-04-2018 16:05:31');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (4,3,1,'nice','23-04-2018 18:12:52');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (5,5,4,'fvfv','03-05-2018 12:23:20');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (6,6,1,'good pic','05-05-2018 15:05:05');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (7,10,1,'abfv','05-05-2018 15:12:48');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (8,11,1,'','05-05-2018 15:14:49');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (9,12,1,'','05-05-2018 15:15:41');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (10,13,1,'abcd','05-05-2018 15:19:50');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (11,14,1,'gtr','09-05-2018 12:34:16');
insert into `m_tag` (`tag_no`,`i_code`,`u_code`,`tag`,`time`) values (12,3,2,'ff','09-05-2018 13:07:35');

/*Table structure for table `m_unfriends` */

DROP TABLE IF EXISTS `m_unfriends`;

CREATE TABLE `m_unfriends` (
  `u_no` int(20) NOT NULL auto_increment,
  `u_from` varchar(50) default NULL,
  `u_to` varchar(50) default NULL,
  PRIMARY KEY  (`u_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_unfriends` */

/*Table structure for table `m_update` */

DROP TABLE IF EXISTS `m_update`;

CREATE TABLE `m_update` (
  `id` int(5) NOT NULL auto_increment,
  `up_from` varchar(50) default NULL,
  `up_to` varchar(50) default NULL,
  `up_msg` varchar(300) default NULL,
  `flag` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_update` */

insert into `m_update` (`id`,`up_from`,`up_to`,`up_msg`,`flag`) values (1,'rajan','bharath','rajan Has Accepted Your Request','true');

/*Table structure for table `m_user` */

DROP TABLE IF EXISTS `m_user`;

CREATE TABLE `m_user` (
  `u_code` int(11) NOT NULL auto_increment,
  `u_login_id` char(50) default NULL,
  `u_pwd` char(20) default NULL,
  `u_name` varchar(50) default NULL,
  `u_gender` char(10) default NULL,
  `d_o_b` varchar(20) default NULL,
  `u_cell_no` varchar(25) default NULL,
  `u_profile_pic` varchar(150) default NULL,
  `hobbies` varchar(50) default NULL,
  `place` varchar(50) default NULL,
  `tell_about` varchar(1000) default NULL,
  `ontology_pattern` varchar(100) default NULL,
  `feature` text,
  `matches_points` int(200) default NULL,
  `policy` varchar(50) default NULL,
  PRIMARY KEY  (`u_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_user` */

insert into `m_user` (`u_code`,`u_login_id`,`u_pwd`,`u_name`,`u_gender`,`d_o_b`,`u_cell_no`,`u_profile_pic`,`hobbies`,`place`,`tell_about`,`ontology_pattern`,`feature`,`matches_points`,`policy`) values (1,'kumarbharath21011991@gmail.com','bharath','bharath','MALE','17/02/1965','7795204296','bharath.jpg',NULL,'kunigal',NULL,NULL,'0.0086-6.2537-0.4231-7.0428-0.0016-0.0059-13.0982-0.2365-7.8202-7.0E-4-0.0036-20.7494-0.1531-8.1407-5.0E-4-0.0023-25.1038-0.1183-8.2312-4.0E-4',0,'Get Aproval');
insert into `m_user` (`u_code`,`u_login_id`,`u_pwd`,`u_name`,`u_gender`,`d_o_b`,`u_cell_no`,`u_profile_pic`,`hobbies`,`place`,`tell_about`,`ontology_pattern`,`feature`,`matches_points`,`policy`) values (2,'kumarbharath21011991@gmail.com','rajan','rajan','MALE','2/01/1951','7795204296','rajan.jpg',NULL,'kunigal',NULL,NULL,'0.0148-4.119-0.4985-5.8536-0.0049-0.0068-7.0982-0.3081-6.5436-0.0022-0.0068-10.3385-0.2239-6.7955-0.0016-0.0043-13.1277-0.181-6.8972-0.0014',0,'Friends');

/*Table structure for table `m_user1` */

DROP TABLE IF EXISTS `m_user1`;

CREATE TABLE `m_user1` (
  `m_id` int(10) NOT NULL auto_increment,
  `m_user` varchar(50) default NULL,
  `m_pass` varchar(50) default NULL,
  PRIMARY KEY  (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_user1` */

insert into `m_user1` (`m_id`,`m_user`,`m_pass`) values (1,'bharath','bharath');
insert into `m_user1` (`m_id`,`m_user`,`m_pass`) values (2,'rajan','rajan');

/*Table structure for table `m_votes` */

DROP TABLE IF EXISTS `m_votes`;

CREATE TABLE `m_votes` (
  `Post_no` int(10) NOT NULL auto_increment,
  `post_code_id` int(10) default NULL,
  `total_faces` int(20) default NULL,
  `no_of_nonfriends` int(20) default NULL,
  `no_of_friends` int(20) default NULL,
  `no_unknown` int(20) default NULL,
  `pos_vote` int(20) default NULL,
  `neg_vot` int(20) default NULL,
  `status` varchar(50) default NULL,
  PRIMARY KEY  (`Post_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_votes` */

insert into `m_votes` (`Post_no`,`post_code_id`,`total_faces`,`no_of_nonfriends`,`no_of_friends`,`no_unknown`,`pos_vote`,`neg_vot`,`status`) values (1,1,0,0,0,0,0,0,'block');
insert into `m_votes` (`Post_no`,`post_code_id`,`total_faces`,`no_of_nonfriends`,`no_of_friends`,`no_unknown`,`pos_vote`,`neg_vot`,`status`) values (2,2,1,1,0,0,1,0,'post');
insert into `m_votes` (`Post_no`,`post_code_id`,`total_faces`,`no_of_nonfriends`,`no_of_friends`,`no_unknown`,`pos_vote`,`neg_vot`,`status`) values (3,3,2,2,0,0,2,0,'post');

/*Table structure for table `post_req` */

DROP TABLE IF EXISTS `post_req`;

CREATE TABLE `post_req` (
  `id` int(10) NOT NULL auto_increment,
  `post_req_from` varchar(15) default NULL,
  `post_req_to` varchar(15) default NULL,
  `status` varchar(50) default 'pending',
  `p_id` int(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `post_req` */

insert into `post_req` (`id`,`post_req_from`,`post_req_to`,`status`,`p_id`) values (1,'rajan','bharath','accepted',2);
insert into `post_req` (`id`,`post_req_from`,`post_req_to`,`status`,`p_id`) values (2,'rajan','bharath','accepted',3);

/*Table structure for table `test` */

DROP TABLE IF EXISTS `test`;

CREATE TABLE `test` (
  `id_key` int(50) NOT NULL auto_increment,
  `id` int(50) default '0',
  `dist` int(100) default '0',
  PRIMARY KEY  (`id_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `test` */

insert into `test` (`id_key`,`id`,`dist`) values (1,1,0);
insert into `test` (`id_key`,`id`,`dist`) values (2,1,15);
insert into `test` (`id_key`,`id`,`dist`) values (3,2,6);
insert into `test` (`id_key`,`id`,`dist`) values (4,2,0);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
